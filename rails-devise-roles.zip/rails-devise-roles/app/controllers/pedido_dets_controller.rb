class PedidoDetsController < ApplicationController

  before_action :set_pedido_det, only: [:show, :edit, :update, :destroy]

  # GET /pedido_dets
  # GET /pedido_dets.json
  def index
    @pedido_dets = PedidoDet.all
  end

  # GET /pedido_dets/1
  # GET /pedido_dets/1.json
  def show
  end

  # GET /pedido_dets/new
  def new
    @pedido_det = PedidoDet.new
  end

  # GET /pedido_dets/1/edit
  def edit
  end

  # POST /pedido_dets
  # POST /pedido_dets.json
  def create
    @pedido_det = PedidoDet.new(pedido_det_params)

    respond_to do |format|
      if @pedido_det.save
        format.html { redirect_to @pedido_det, notice: 'Pedido det was successfully created.' }
        format.json { render :show, status: :created, location: @pedido_det }
      else
        format.html { render :new }
        format.json { render json: @pedido_det.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /pedido_dets/1
  # PATCH/PUT /pedido_dets/1.json
  def update
    respond_to do |format|
      if @pedido_det.update(pedido_det_params)
        format.html { redirect_to @pedido_det, notice: 'Pedido det was successfully updated.' }
        format.json { render :show, status: :ok, location: @pedido_det }
      else
        format.html { render :edit }
        format.json { render json: @pedido_det.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /pedido_dets/1
  # DELETE /pedido_dets/1.json
  def destroy
    @pedido_det.destroy
    respond_to do |format|
      format.html { redirect_to pedido_dets_url, notice: 'Pedido det was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_pedido_det
      @pedido_det = PedidoDet.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def pedido_det_params
      params.require(:pedido_det).permit(:num_pedido, :producto_code, :qty)
    end
end
