class Pedido < ApplicationRecord
  belongs_to :user
  has_many :pedido_dets
end
