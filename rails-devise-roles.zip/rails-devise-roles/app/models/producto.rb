class Producto < ApplicationRecord
  belongs_to :category
  belongs_to :unidad


  validates :nombre, presence: { message: "Debe ingresar un nombre" }
  validates :code,uniqueness: {:message => "Codigo ya se encuentra en uso"}
  validates :code, presence: { message: "Debe ingresar un codigo" }


end
