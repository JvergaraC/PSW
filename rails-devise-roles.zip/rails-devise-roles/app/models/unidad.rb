class Unidad < ApplicationRecord
  has_many :productos

  validates :nombre, presence: { message: " no puede estar en blanco" }
  validates :nombre,uniqueness: {:message => " ya se encuentra en uso"}

end
