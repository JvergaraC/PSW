class PedidoDet < ApplicationRecord
  belongs_to :pedido
  has_many :productos

  accepts_nested_attributes_for :productos, allow_destroy: true

end
