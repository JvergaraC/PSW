require "application_system_test_case"

class PedidosTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit pedidos_url
  #
  #   assert_selector "h1", text: "Pedido"
  # end
end
