require "application_system_test_case"

class ProductosTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit productos_url
  #
  #   assert_selector "h1", text: "Producto"
  # end
end
