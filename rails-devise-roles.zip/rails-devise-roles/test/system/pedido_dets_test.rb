require "application_system_test_case"

class PedidoDetsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit pedido_dets_url
  #
  #   assert_selector "h1", text: "PedidoDet"
  # end
end
