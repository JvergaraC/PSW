require "application_system_test_case"

class UnidadsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit unidads_url
  #
  #   assert_selector "h1", text: "Unidad"
  # end
end
