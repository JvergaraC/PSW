require 'test_helper'

class PedidoDetTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
